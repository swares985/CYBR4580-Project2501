import java.util.Scanner;

public abstract class pchauhan_Employee
{
    private String firstName = null,            //name of employee
                   lastName = null ;
    private char mI = ' ',
                 gender = ' ' ;                //gender of emplyee
    private int employeeNumber = 0 ;
    private boolean fulltime = false ;          //weather fulltime or part time
    
    // Method name: pchauhan_Employee
    // Parameters: firstName(String), lastName(String), mI(char), gender(char),
    //             employeeNumber(int), fulltime(boolean). 
    // Partners: None
    // Description: Constructor to initialize data members using 'set' methods. 
    public pchauhan_Employee(String firstName, String lastName,char mI,
                            char gender,int employeeNumber, boolean fulltime )
    {
        setFirstName(firstName);                //using 'set' methods to set 
        setLastName(lastName);                  //values passed from parameter.
        setmI(mI);
        setGender(gender);
        setEmployeeNumber(employeeNumber);
        setFullTime(fulltime);
    }
    
    // Method name: setFirstName
    // Parameters: firstName (String)
    // Return value(s): none
    // Partners: none
    // Description: sets firstName value from parameter passed.
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }
    
    // Method name: setLastName
    // Parameters: lastName(String)
    // Return value(s): none
    // Partners: none
    // Description: sets lastName value from parameter passed.
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }
    // Method name: getFirstName
    // Parameters: none
    // Return value(s): the First Name (String)
    // Partners: none
    // Description: Returns the value of firstName from this class.
    public String getFirstName()
    {
        return this.firstName;
    }

    // Method name: getLastName
    // Parameters: none
    // Return value(s): the Last Name (String)
    // Partners: none
    // Description: returns the value of lastName from this class. 
    public String getLastName()
    {
        return this.lastName;
    }
    
    // Method name: setmI
    // Parameters: mI (char)
    // Return value(s): none
    // Partners: none
    // Description: Sets the value of mI from parameter passed. 
    public void setmI(char mI)
    {
        this.mI = mI;
    }
    
    // Method name: getmI
    // Parameters: none
    // Return value(s): the value of mI(char)
    // Partners: none
    // Description: returns the value of mI from this class. 
    public char getmI()
    {
        return this.mI;
    }
    
    // Method name: setGender
    // Parameters: gender(char)
    // Return value(s): none
    // Partners: none
    // Description: sets the value of gender from paramter passed.
    public void setGender(char gender)
    {
        //validating gender
        if(gender == 'M' || gender == 'F')
            this.gender = gender;
        else
            this.gender = 'F';
    }
    
    // Method name: getGender
    // Parameters: none
    // Return value(s): the Gender of Employee (char)
    // Partners: none
    // Description: returns the value of gender.
    public char getGender()
    {
        return gender;
    }
    
    // Method name: setEmployeeNumber
    // Parameters: employeeNumber(int)
    // Return value(s): none
    // Partners: none
    // Description: sets the value of employeeNumber from value passed. 
    public void setEmployeeNumber(int employeeNumber)
    {   
        Scanner in = new Scanner(System.in);
        
        //Loop to run till user enters valid employee number.
        while(employeeNumber <= 10000 || employeeNumber >= 99999)
        {
            System.out.printf("Bad Employee number. Try Again. ");
            employeeNumber = in.nextInt();
        }
        this.employeeNumber = employeeNumber;
    }
    
    // Method name: getEmployeeNumber
    // Parameters: none
    // Return value(s): the Employee Number(int)
    // Partners: none
    // Description: Returns the value of employeeNumber.
    public int getEmployeeNumber()
    {
        return employeeNumber;
    }
    
    // Method name: setFullTime
    // Parameters: fulltime(boolean)
    // Return value(s): none
    // Partners: none
    // Description: sets the truth value of fulltime from value passed.
    public void setFullTime(boolean fulltime)
    {
        this.fulltime = fulltime;
    }
    
    // Method name: getFullTime
    // Parameters: none
    // Return value(s): the truth value of fulltime(boolean)
    // Partners: none
    // Description: Returns the truth value of fulltime.
    public boolean getFullTime()
    {
        return this.fulltime;
    }
    
    // Method name: calculateWeeklyPay
    // Parameters: none
    // Return value(s): (double)
    // Partners: none
    // Description: abstract calculateWeeklyPay method.
    public abstract double calculateWeeklyPay();
    
    // Method name: annualRaise
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: abstract annualRaise method.
    public abstract void annualRaise();
    
    // Method name: holidayBonus
    // Parameters: none
    // Return value(s): (double)
    // Partners: none
    // Description: abstract holidayBonus method.
    public abstract double holidayBonus();
    
    // Method name: resetWeek
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: abstract resetWeek method.
    public abstract void resetWeek();
    
    // Method name: equals
    // Parameters: o(Object)
    // Return value(s): truth value of equality(boolean)
    // Partners: none
    // Description: Method returns value for whether passed employeeNumber is
    //              equal to employeeNumber stored in class.
    public boolean equals(Object o)
    {
        boolean toReturn = false;               //boolean to be returned
        
        //testing the equality for employee number
        if(o instanceof pchauhan_Employee)
        {
            pchauhan_Employee p = (pchauhan_Employee) o;
            if(this.getEmployeeNumber() == p.getEmployeeNumber())
                toReturn = true;
            else
                toReturn = false;
        }
        return toReturn;     
    }
    
    // Method name: toString
    // Parameters: none
    // Return value(s): The required  for display(String)
    // Partners: none
    // Description: Returns the information about Employee as String.
    public String toString()
    {
        String returnString;                    //string to be returned
        String fullTimeValue = null;
        if(getFullTime() == true)
        fullTimeValue = "fulltime";
        else
        fullTimeValue = "part-time";
        
        //creating string for display.
        returnString = "Employee: " + getFirstName() + " " + getmI() + ". " +
                        getLastName() + " ("
                        + getEmployeeNumber() + "), " + getGender() + ", "
                        + fullTimeValue ;
        return returnString;                
    }


}
