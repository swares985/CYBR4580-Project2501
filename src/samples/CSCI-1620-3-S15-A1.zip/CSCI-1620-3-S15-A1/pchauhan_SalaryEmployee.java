public class pchauhan_SalaryEmployee extends pchauhan_Employee
{
    private double salary = 0;
    
    // Method name: pchauhan_Employee
    // Parameters: firstName(String), lastName(String), mI(char), gender(char),
    //             employeeNumber(int), fulltime(boolean), salary(double). 
    // Partners: None
    // Description: Constructor to initialize data members using 'set' methods.
    public pchauhan_SalaryEmployee(String firstName, String lastName,char mI,
        char gender,int employeeNumber, boolean fulltime,double salary)
    {
        //accessing super class constructor
        super(firstName,lastName,mI,gender,employeeNumber,fulltime);
        setSalary(salary);
    }
    
    // Method name: setSalary
    // Parameters: salary(double)
    // Return value(s): none
    // Partners: none
    // Description: sets the amount of salary by value passed in arguement
    public void setSalary(double salary)
    {
        this.salary = salary;
    }
    
    // Method name: getSalary
    // Parameters: none
    // Return value(s): salary of employee(double)
    // Partners: none
    // Description: returns the salary of employee(salary)
    public double getSalary()
    {
        return this.salary;
    }
    
    // Method name: calculateWeeklyPay
    // Parameters: none
    // Return value(s):  the calculated weekly pay(getSalary / 52)
    // Partners: none
    // Description: calculates the weekly pay of an employee
     public double calculateWeeklyPay()
    {
        return getSalary() / 52;
    }
    
    // Method name: annualRaise
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: increases the salary by five percent as annual raise.
    public void annualRaise()
    {
        double salaryReturn = getSalary();
        
        //increasing salary by 5 percent.
        salaryReturn += (.05)*salaryReturn;
        setSalary(salaryReturn);
    }
    
    // Method name: holidayBonus
    // Parameters: none
    // Return value(s): bonus for employee
    // Partners: none
    // Description: calculates the holiday bonus for employee.
    public double holidayBonus()
    {
        double salaryReturned = getSalary();
        
        // increasing salary by 3 percent.
        salaryReturned = (.03) * salaryReturned;
        return salaryReturned;
    }
    
    // Method name: resetWeek
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: does nothing in this case
    public void resetWeek()
    {

    }
    
    // Method name: toString
    // Parameters: none
    // Return value(s): the string to be displayed(String)
    // Partners: none
    // Description: Adds some string to the super toString() return value for
    //              display.
    public String toString()
    {
        String toStringReturn; 
        toStringReturn = super.toString();
        toStringReturn += ", $" + getSalary() + "/year.";
        return toStringReturn;
    }

}
