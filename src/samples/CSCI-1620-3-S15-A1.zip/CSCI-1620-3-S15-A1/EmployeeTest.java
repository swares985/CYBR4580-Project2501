// Name: Parshav Chauhan
// Class: CSCI 1620-003
// Assignment #: 1
// Due Date: 25 Feb, 2015
//
// Honor Pledge: On my honor as a student of the University of Nebraska at
// Omaha, I have neither given nor received unauthorized help on
// this programming assignment.
//
// NAME: Parshav Chauhan
// NU ID: 527
// EMAIL: pchauhan@unomaha.edu
//
// Partners: NONE
//
// Drive class for the other four classes.

import java.util.Scanner;

public class EmployeeTest
{
   public static void main(String args[])
   {
      // Create references for our objects
      pchauhan_HourlyEmployee hourly = null;
      pchauhan_SalaryEmployee salary = null;
      pchauhan_CommissionEmployee commission = null;

      // The sum of all bonuses will be placed here
      double bonusPayout = 0;

      // Create and print a new HourlyEmployee
      hourly = HourlyFactory();
      System.out.printf("%s\n", hourly);

      // Create and print a new SalaryEmployee
      salary = SalaryFactory();
      System.out.printf("%s\n", salary);

      // Create and print a new CommissionEmployee
      commission = CommissionFactory();
      System.out.printf("%s\n", commission);

      // Test two employees for equality
      System.out.print("\nTesting for equality. . .\n" +
                       "Hourly (" + hourly.getEmployeeNumber() + ") and " +
                       "salary (" + salary.getEmployeeNumber() + ") are ");
      if (hourly.equals(salary))
      {
          System.out.println("the same!");
      }
      else
      {
          System.out.println("different!");
      }
      System.out.print("Salary (" + salary.getEmployeeNumber() + ") and " +
                       "Commission (" + commission.getEmployeeNumber() +
                       ") are ");
      if (salary.equals(commission))
      {
          System.out.println("the same!\n");
      }
      else
      {
          System.out.println("different!\n");
      }

      // Alter some values of Hourly and Commission
      System.out.println("Increasing Hourly's hours worked by -50.");
      hourly.increaseHours(-50);
      System.out.println("Increasing Hourly's hours worked by 50.");
      hourly.increaseHours(50);
      System.out.println("Increasing Commission's sales by -150,000.");
      commission.increaseSales(-150000);
      System.out.println("Increasing Commission's sales by 150,000.");
      commission.increaseSales(150000);

      // Output weekly pay for each Employee
      System.out.println("\nCalculating weekly payouts. . .");
      System.out.printf("Hourly payout: $%.2f\n",
                        hourly.calculateWeeklyPay());
      System.out.printf("Salary payout: $%.2f\n", salary.calculateWeeklyPay());
      System.out.printf("Commission payout: $%.2f\n\n",
                                               commission.calculateWeeklyPay());

      // Find total bonus payout
      System.out.println("Finding total bonus payout. . .");
      bonusPayout += hourly.holidayBonus();
      bonusPayout += salary.holidayBonus();
      bonusPayout += commission.holidayBonus();

      System.out.printf("Bonus Payout is $%.2f\n\n", bonusPayout);

      // Reset the week and apply raises to all Employees
      System.out.println("Applying annual raises and resetting weeks. . .");
      hourly.resetWeek();
      hourly.annualRaise();
      salary.resetWeek();
      salary.annualRaise();
      commission.resetWeek();
      commission.annualRaise();

      // Output Employees after changes
      System.out.printf("%s\n%s\n%s\n", hourly, salary, commission);
   }

   // Retrieve input and create HourlyEmployee
   public static pchauhan_HourlyEmployee HourlyFactory()
   {
      System.out.println("Creating HourlyEmployee. . .");
      return new pchauhan_HourlyEmployee("Steve", "Rogers", 'A', 'M',
                                    12345, true, 15.34);
   }

   // Retrieve input and create SalaryEmployee
   public static pchauhan_SalaryEmployee SalaryFactory()
   {
      System.out.println("Creating SalaryEmployee. . .");
      return new pchauhan_SalaryEmployee("Kitty", "Pryde", 'X', 'F', 54321, true,
                                      75000);
   }

   // Retrieve input and create CommissionEmployee
   public static pchauhan_CommissionEmployee CommissionFactory()
   {
      System.out.println("Creating CommissionEmployee. . .");
      return new pchauhan_CommissionEmployee("Johnny", "Storm", 'F', 'L',
                                         976499, false, 2.5);
   }
}
