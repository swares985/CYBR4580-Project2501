public class pchauhan_HourlyEmployee extends pchauhan_Employee
{
    private double hourlyRate=0,                //hourly rate of employee
                   hoursWorked=0;               //hours worked by employee
    
    // Method name: pchauhan_HourlyEmployee
    // Parameters: firstName(String), lastName(String), mI(char), gender(char),
    //             employeeNumber(int), fulltime(boolean), hourlyRate(double) 
    // Partners: None
    // Description: Constructor to initialize data members using 'set' methods.
    public pchauhan_HourlyEmployee(String firstName, String lastName,char mI,
        char gender,int employeeNumber, boolean fulltime,double hourlyRate)
    {
        super(firstName,lastName,mI,gender,employeeNumber,fulltime);
        setHourlyRate(hourlyRate);
    }
    
    // Method name: setHourlyRate
    // Parameters: hourlyRate(double)
    // Return value(s): none
    // Partners: none
    // Description: sets thhe hourly rate value by value passed in arguement.
    public void setHourlyRate(double hourlyRate)
    {
        this.hourlyRate = hourlyRate;
    }
    
    // Method name: getHourlyRate
    // Parameters: none
    // Return value(s): the hourly rate(double)
    // Partners: none
    // Description: returns the value of hourly rate(hourlyRate). 
    public double getHourlyRate()
    {
        return this.hourlyRate;
    }
    
    // Method name: setHoursWorked
    // Parameters: hoursWorked(double)
    // Return value(s): none
    // Partners: none
    // Description: sets the amount of hours worked by value passed in arguement
    public void setHoursWorked(double hoursWorked)
    {
        this.hoursWorked = hoursWorked;
    }
    
    // Method name: getHoursWorked
    // Parameters: none
    // Return value(s): the amount of hours worked (double)
    // Partners: none   
    // Description: returns the number of hours worked(hoursWorked)
    public double getHoursWorked()
    {
        return this.hoursWorked;
    }
    
    // Method name: increaseHours
    // Parameters: hours(double)
    // Return value(s): none
    // Partners: none
    // Description: increases the number of hours worked(hoursWorked) by value
    //              passed in arguement.
    public void increaseHours(double hours)
    {
        double hoursWorked = getHoursWorked() ;
        
        //testing for hours to be increased by.
        if(hours < 0)
        {
            System.out.printf("Can't increase hours by a negative value.");
            System.out.printf(" No change.\n");
        }
        else
        {
            hoursWorked +=hours;
            setHoursWorked(hoursWorked);        
        }
    }

    // Method name: calculateWeeklyPay
    // Parameters: none
    // Return value(s): the weekly pay(double)
    // Partners: none
    // Description: calculates and returns the weekly pay amount for employee.
    public double calculateWeeklyPay()
    {
        double totalMoney = 0;                  //value to be returned
        double hoursWorked = getHoursWorked();
        double hourlyRate = getHourlyRate();
        
        //testing for weekly pay amount.
        if(getHoursWorked() > 40)
        {
            totalMoney = 40*hourlyRate;
            totalMoney += (hoursWorked - 40)*(2*hourlyRate);
        }
        else
            totalMoney = hoursWorked * hourlyRate;
        return totalMoney;
    }
    
    // Method name: annualRaise
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: increases the value of hourlyRate by 5 percent as annual raise
    public void annualRaise()
    {
        double hourlyRateReturn = getHourlyRate();
        
        //increasing hourly rate by 5 percent.
        hourlyRateReturn += (.05)*hourlyRateReturn;
        setHourlyRate(hourlyRateReturn);
    }
    
    // Method name: holidayBonus
    // Parameters: none
    // Return value(s): the holiday bonus(double)
    // Partners: none
    // Description: returns the value of hourlyRate with added bonus.
    public double holidayBonus()
    {
        return getHourlyRate() * 40;
    }
    
    // Method name: resetWeek
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: resets the value of hours worked to zero. 
    public void resetWeek()
    {
        setHoursWorked(0);
    }
    
    // Method name: toString
    // Parameters: none
    // Return value(s): string to be displayed(String)
    // Partners: none
    // Description: adds to the super toString more details for displaying.
    public String toString()
    {
      /*  String toStringReturn;
        toStringReturn = super.toString();
        toStringReturn += " , " + getHoursWorked() + " hours, ";
        toStringReturn +=  "$" + getHourlyRate() + "/hour." ;
        return toStringReturn; */
        
        return String.format("%s , %.2f hours $%.2f/hour.", super.toString(),
                             getHoursWorked(),getHourlyRate());
    }

}
