public class pchauhan_CommissionEmployee extends pchauhan_Employee
{
    private double rate=0,                      //commission employees rate
                   sales=0;                     //commission employees sales
    
    // Method name: pchauhan_Employee
    // Parameters: firstName(String), lastName(String), mI(char), gender(char),
    //             employeeNumber(int), fulltime(boolean), rate(double) 
    // Partners: None
    // Description: Constructor to initialize data members using 'set' methods.
    public pchauhan_CommissionEmployee(String firstName, String lastName,char mI
        ,char gender,int employeeNumber, boolean fulltime,double rate)
    {
        //accessing super class.
        super(firstName,lastName,gender,mI,employeeNumber,fulltime);
        setSales(0);
        setRate(rate);
    }
    
    // Method name: setRate
    // Parameters: rate(double)
    // Return value(s): none
    // Partners: none
    // Description: sets the value of rate from value passed in arguement. 
    public void setRate(double rate)
    {
        this.rate = rate;
    }
    
    // Method name: getRate
    // Parameters: none
    // Return value(s): value stored in rate(double)
    // Partners: none
    // Description: returns the value of Rate of Commission Employee. 
    public double getRate()
    {
        return this.rate;
    }
    
    // Method name: setSales
    // Parameters: sales(double)
    // Return value(s): none
    // Partners: none
    // Description: sets the value of sales from value passed in arguement. 
    public void setSales(double sales)
    {
        this.sales = sales;
    }
    
    // Method name: getSales
    // Parameters: none
    // Return value(s): value stored in sales(double)
    // Partners: none
    // Description: returns the value of Sales.
    public double getSales()
    {
        return this.sales;
    }
    
    // Method name: increaseSales
    // Parameters: sales(double)
    // Return value(s): none
    // Partners: none
    // Description: increses the sales value by value passed in arguement.
    public void increaseSales(double sales)
    {
        double salesReturn = getSales();     
        
        //testing for increase amount in sales.
        if(sales > 0)
        {
        salesReturn += sales;
        setSales(salesReturn);
        }
        else
        {
        System.out.printf("Cannot increase sales by negative amount.");
        System.out.printf(" No change.\n");
        }
    }
    
    // Method name: calculateWeeklyPay
    // Parameters: none
    // Return value(s): weekly pay(double)
    // Partners: none
    // Description: calculates and returns the value of weekly pay for 
    public double calculateWeeklyPay()
    {
        double weeklyPay = 0;           //total weekly pay
        
        //calculating weekly pay
        weeklyPay = getRate() * getSales();
        return weeklyPay;
    }
    
    // Method name: annualRaise
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: Increases rate by 20 percent as Annual Raise. 
    public void annualRaise()
    {
        double rateReturn = getRate();
        
        //increasing rate by 20 percent
        rateReturn += (.2) * rateReturn;
        setRate(rateReturn);
    }
    
    // Method name: holidayBonus
    // Parameters: none
    // Return value(s): value of holiday bonus(double)
    // Partners: none
    // Description: returns the value for holiday bonus, in this case zero. 
    public double holidayBonus()
    {
        return 0;
    }
    
    // Method name: resetWeek
    // Parameters: none
    // Return value(s): none
    // Partners: none
    // Description: resets the value of sales to zero as week ends. 
    public void resetWeek()
    {
        setSales(0) ;
    }
    
    // Method name: toString
    // Parameters: none
    // Return value(s): the displayed string(String)
    // Partners: none
    // Description: Adds some string to the super toString() return value for
    //              display. 
    public String toString()
    {
        String toStringReturn;
        toStringReturn = super.toString();
        toStringReturn += ", " + getRate() + "%" + ", " + getSales() + ".";
        return toStringReturn;
    }

}
