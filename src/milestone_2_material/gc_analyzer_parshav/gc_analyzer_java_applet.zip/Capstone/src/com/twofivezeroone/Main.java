package com.twofivezeroone;

import java.util.Scanner;

public class Main {

    // String for test purposes now.
    static String name;

    static int a = 0;

    public static void main(String[] args){

        print("I'm inside !");

        Runnable r = new Runnable() {
            @Override
            public void run() {
                for(double i = 0;  ; ++i) {
                    ++a;
                }
            }
        };

        Scanner reader = new Scanner(System.in);
        name = reader.nextLine(); // Breakpoint 1
        print("Assigned name : " + name);
        try {
            print("Sleep Start;");
            Thread.sleep(2000);
            // Breakpoint 2
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Breakpoint 3
        name = null;
        System.gc();
        name = reader.nextLine(); // Breakpoint 4

    }

    static void print(String data) {
        System.out.println(data);
    }
}